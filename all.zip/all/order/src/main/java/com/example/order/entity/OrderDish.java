package com.example.order.entity;


import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "order_dish")
class OrderDish {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne
    @JoinColumn(name = "dish_id")
    private Dish dish;

    private int quantity;

    private double price;

}