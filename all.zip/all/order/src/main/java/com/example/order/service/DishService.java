package com.example.order.service;

import com.example.order.dto.DishRq;
import com.example.order.entity.Dish;
import com.example.order.repository.DishRepository;
import com.example.order.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;

@Service
@RequiredArgsConstructor
public class DishService {
    private final UserRepository userRepository;
    private final DishRepository dishRepository;

    public Dish createDish(DishRq dishRequest) throws AccessDeniedException {
        // Проверка доступа и правильности предоставленных данных
        if (!isManager(dishRequest.getName())) {
            throw new AccessDeniedException("Доступ запрещен");
        }
        if (dishRequest.getQuantity() <= 0) {
            throw new AccessDeniedException("Некорректное количество блюд");
        }

        // Создание нового блюда
        Dish dish = new Dish();
        dish.setName(dishRequest.getName());
        dish.setQuantity(dishRequest.getQuantity());

        return dishRepository.save(dish);
    }

    public Dish getDishById(Long dishId) {
        return dishRepository.findById(dishId).orElse(null);
    }

    public boolean isManager(String name) {
        return userRepository.findUserByUsername(name).getRole().equals("manager");
        // Логика определения роли пользователя (менеджер или нет)
    }
}