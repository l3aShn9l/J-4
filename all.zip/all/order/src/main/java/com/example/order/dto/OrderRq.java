package com.example.order.dto;

import com.example.order.entity.Dish;
import lombok.Data;

import java.util.List;

@Data
public class OrderRq {
    private Long userId;
    private List<Dish> dishes;
    private String specialRequests;

}
