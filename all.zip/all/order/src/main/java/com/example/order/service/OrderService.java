package com.example.order.service;

import com.example.order.dto.OrderRq;
import com.example.order.entity.Order;
import com.example.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;

@Service
@RequiredArgsConstructor
public class OrderService {


    private final OrderRepository orderRepository;

    public Order createOrder(OrderRq orderRequest) throws AccessDeniedException {
        // Проверка правильности предоставленных данных
        if (orderRequest.getUserId() <= 0 || orderRequest.getDishes().isEmpty()) {
            throw new AccessDeniedException("Некорректные данные заказа");
        }

        // Создание нового заказа
        Order order = new Order();
        order.setUserId(orderRequest.getUserId());
        order.setDishes(orderRequest.getDishes());
        order.setSpecialRequests(orderRequest.getSpecialRequests());
        order.setStatus("в ожидании");

        return orderRepository.save(order);
    }

    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }
}