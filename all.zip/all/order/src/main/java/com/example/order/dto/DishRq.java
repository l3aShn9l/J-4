package com.example.order.dto;

import lombok.Data;

@Data
public class DishRq {
    private String name;
    private int quantity;
}
