package com.example.registration.mapper;


import com.example.registration.dto.UserRq;
import com.example.registration.dto.UserRs;
import com.example.registration.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface UserMapper {
    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);


    User toModel(UserRq userRq);
    UserRs toDTO(User user);
}