package com.example.registration.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserRq {
    @NotBlank(message = "Field 'user name' is empty")
    private String username;
    @Email(message = "Email should be valid")
    @NotBlank(message = "Field 'email' is empty")
    private String email;
    @NotBlank(message = "Field 'password' is empty")
    private String password;
}
