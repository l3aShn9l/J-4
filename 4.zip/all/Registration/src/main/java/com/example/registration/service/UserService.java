package com.example.registration.service;

import com.example.registration.dto.UserRq;
import com.example.registration.entity.User;
import com.example.registration.mapper.UserMapper;
import com.example.registration.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    public void saveUser(UserRq userRq){
        User user = new User();
        user.setEmail(userRq.getEmail());
        user.setRole(userRq.getRole());
        user.setPassword(userRq.getPassword());
        user.setUsername(userRq.getUsername());
        userRepository.saveAndFlush(user);
    }
}
