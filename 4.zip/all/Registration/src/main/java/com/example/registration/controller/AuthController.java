package com.example.registration.controller;

import com.example.registration.dto.UserCredentials;
import com.example.registration.dto.UserRs;
import com.example.registration.entity.Session;
import com.example.registration.entity.User;
import com.example.registration.mapper.UserMapper;
import com.example.registration.repository.SessionRepository;
import com.example.registration.repository.UserRepository;
import com.example.registration.security.JwtUtils;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Date;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final JwtUtils jwtUtils;
    private final UserRepository userRepository;
    private final SessionRepository sessionRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserCredentials credentials) {
        User user = userRepository.findByEmail(credentials.getEmail());
        if (user == null || !passwordEncoder.matches(credentials.getPassword(), user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
        // Генерация JWT токена и сохранение сессии в базу данных
        String sessionToken = jwtUtils.generateJwtToken(user.getEmail());
        Session session = new Session();
        session.setUserId(user);
        session.setSessionToken(sessionToken);
        session.setExpiresAt(LocalDateTime.now().plusHours(1)); // Настройте срок действия токена
        sessionRepository.save(session);

        return ResponseEntity.ok(sessionToken);
    }

    @GetMapping("/user")
    public ResponseEntity<?> getUser(@RequestHeader(name = "authorization") String authorization) {
        User user = userRepository.findByEmail(jwtUtils.getUserEmail(authorization));
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
        }
        Session bySessionToken = sessionRepository.findBySessionToken(authorization);
        if (bySessionToken == null || LocalDateTime.now().isAfter(bySessionToken.getExpiresAt())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
        }
        return ResponseEntity.ok(UserMapper.INSTANCE.toDTO(user));

    }
}