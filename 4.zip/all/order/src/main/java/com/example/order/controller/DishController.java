package com.example.order.controller;

import com.example.order.dto.DishRq;
import com.example.order.entity.Dish;
import com.example.order.service.DishService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/dishes")
@RequiredArgsConstructor
public class DishController {

    private final DishService dishService;

    @PostMapping
    public ResponseEntity<Object> createDish(@RequestBody DishRq dishRequest) {
        try {
            Dish dish = dishService.createDish(dishRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(dish);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка при создании блюда");
        }
    }

    @GetMapping("/{dishId}")
    public ResponseEntity<Object> getDish(@PathVariable("dishId") Long dishId) {
        try {
            Dish dish = dishService.getDishById(dishId);
            if (dish != null) {
                return ResponseEntity.ok(dish);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка при получении информации о блюде");
        }
    }
}