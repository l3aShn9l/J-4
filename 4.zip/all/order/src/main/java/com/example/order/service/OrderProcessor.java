package com.example.order.service;

import com.example.order.entity.Order;
import com.example.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


import java.util.List;

@Component
@RequiredArgsConstructor
public class OrderProcessor {

    private final OrderRepository orderRepository;

    @Async
    @Scheduled(fixedDelay = 5000) // Задержка в миллисекундах
    public void processOrders() {
        List<Order> orders = orderRepository.findByStatus("In progress");

        for (Order order : orders) {
            order.setStatus("Finished");
            orderRepository.save(order);
        }
    }
}