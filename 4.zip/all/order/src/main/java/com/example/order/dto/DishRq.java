package com.example.order.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DishRq {
    @NotBlank(message = "Field 'name' is empty")
    private String name;
    private String description;
    @NotBlank(message = "Field 'price' is empty")
    private Double price;
    @NotBlank(message = "Field 'quantity' is empty")
    private int quantity;
}
