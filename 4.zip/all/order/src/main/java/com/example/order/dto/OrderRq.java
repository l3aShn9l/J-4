package com.example.order.dto;

import com.example.order.entity.Dish;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.data.util.Pair;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderRq {
    @NotBlank(message = "Field 'user_id' is empty")
    private Long userId;
    @NotEmpty(message = "List of dishes is empty")
    private List<Pair<Long,Integer>> dishes;
    @NotBlank(message = "Field 'special_requests' is empty")
    private String specialRequests;

}
