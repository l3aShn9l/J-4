package com.example.order.controller;

import com.example.order.entity.Dish;
import com.example.order.service.MenuService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/menu")
@RequiredArgsConstructor
public class MainController {


    private final MenuService menuService;

    @GetMapping
    public ResponseEntity<Object> getMenu() {
        try {
            List<Dish> menu = menuService.getMenu();
            return ResponseEntity.ok(menu);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Ошибка при получении меню");
        }
    }
}
