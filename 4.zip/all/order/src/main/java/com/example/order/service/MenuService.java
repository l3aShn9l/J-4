package com.example.order.service;

import com.example.order.entity.Dish;
import com.example.order.repository.DishRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MenuService {

    private final DishRepository dishRepository;

    public List<Dish> getMenu() {
        // Получение меню с учетом доступности (количество штук в наличии больше 0)
        return dishRepository.findByQuantityGreaterThan(0);
    }
}