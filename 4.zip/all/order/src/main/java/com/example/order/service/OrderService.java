package com.example.order.service;

import com.example.order.dto.OrderRq;
import com.example.order.entity.Dish;
import com.example.order.entity.Order;
import com.example.order.entity.OrderDish;
import com.example.order.repository.DishRepository;
import com.example.order.repository.OrderDishRepository;
import com.example.order.repository.OrderRepository;
import com.example.order.entity.User;
import com.example.order.repository.UserRepository;
import lombok.RequiredArgsConstructor;

import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final DishRepository dishRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final OrderDishRepository orderDishRepository;

    public Order createOrder(OrderRq orderRequest) throws AccessDeniedException {
        // Проверка правильности предоставленных данных
        if (userRepository.findById(orderRequest.getUserId()) == null || orderRequest.getDishes().isEmpty()) {
            throw new AccessDeniedException("Некорректные данные заказа");
        }

        // Создание нового заказа
        Order order = new Order();
        order.setUserId(userRepository.findById(orderRequest.getUserId()).orElse(null));
        order.setSpecialRequests(orderRequest.getSpecialRequests());
        order.setStatus("In progress");

        List<Pair<Dish,Long>> dishes = new ArrayList<>();
        for (var dish: orderRequest.getDishes()) {
            if(dishRepository.findById(dish.getFirst()) == null ||dish.getSecond() <= 0){
                throw new AccessDeniedException("Некорректные данные заказа");
            }else{
                OrderDish orderDish = new OrderDish();
                orderDish.setOrder(order);
                orderDish.setDish(dishRepository.findById(dish.getFirst()).orElse(null));
                orderDish.setQuantity(dish.getSecond());
                orderDish.setPrice(dishRepository.findById(dish.getFirst()).orElse(null).getPrice());
                orderDishRepository.save(orderDish);
            }
        }

        return orderRepository.save(order);
    }
    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }
}